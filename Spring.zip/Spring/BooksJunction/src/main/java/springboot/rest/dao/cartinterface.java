package springboot.rest.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import springboot.rest.model.Books;
import springboot.rest.model.Cart;


@Repository
public interface cartinterface extends JpaRepository<Cart, String> {

	
	@Query(value="select * from cart  where user = :name",nativeQuery = true)
	List<Cart> findbyname(@Param("name") String name);
   
	@Modifying
	@Transactional
    @Query(value="delete from cart where book_id=?1",nativeQuery = true)
	int delete(@Param("book_id")int book_id);
}
