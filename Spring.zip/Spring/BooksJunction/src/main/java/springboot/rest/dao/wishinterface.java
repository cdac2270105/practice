package springboot.rest.dao;

import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import springboot.rest.model.Books;

import springboot.rest.model.Wishlist;


@Service
@Repository
@ComponentScan("springboot.rest.dao")
public interface wishinterface extends JpaRepository<Wishlist, String> {

	
	@Query(value="select * from wishlist  where user = :name",nativeQuery = true)
	List<Wishlist> findbyname(@Param("name") String name);
	
	@Modifying
	@Transactional
    @Query(value="delete from wishlist where book_id=?1",nativeQuery = true)
	int delete(@Param("book_id")int book_id);
}



