package springboot.rest.service;

import java.util.List;
import java.util.Optional;

import springboot.rest.model.Books;
import springboot.rest.model.Cart;
import springboot.rest.model.Wishlist;



public interface Myservice {

	List<Books> getAll();
	Optional<Books> getBookById(int id);
	List<Books> getBookByCat(int value);
	List<Books> getBookByName(String value);
	public int insertBook(Books b);
	
	
	public Cart addCart(Cart c);
	public int deleteCart(Cart c);
	
	public Wishlist addWish(Wishlist w);
	public int deleteWish(Wishlist w);
	/*public List<Employee> getEmployees();
	public Optional<Employee> getEmployeeById(int empid);
	public Employee addNewEmployee(Employee emp);
	public Employee updateEmployee(Employee emp);
	public void deleteEmployeeById(int empid);
	public void deleteAllEmployees();*/
	List<Cart> findbyname(String n);
	List<Wishlist> findbyname1(String n);

}