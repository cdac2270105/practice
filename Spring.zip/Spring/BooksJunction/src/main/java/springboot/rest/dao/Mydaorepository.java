package springboot.rest.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import springboot.rest.model.Books;


@Repository
public interface Mydaorepository extends JpaRepository<Books, Integer> {

	
	@Query(value="select * from books  where genre = 'romance'",nativeQuery = true)
	List<Books> getAllBooksByRomance();
	
	@Query(value="select * from books  where genre = 'comedy'",nativeQuery = true)
	List<Books> getAllBooksByComedy();
	
	@Query(value="select * from books  where genre = 'sports'",nativeQuery = true)
	List<Books> getAllBooksBySports();
	
	@Query(value="select * from books  where genre = 'fiction'",nativeQuery = true)
	List<Books> getAllBooksByFicion();
	
	@Query(value="select * from books  where genre = 'biography'",nativeQuery = true)
	List<Books> getAllBooksByBiography();
	
	@Query(value="select * from books  where genre = 'medical'",nativeQuery = true)
	List<Books> getAllBooksByMedical();
	
	@Query(value="select * from books  where genre = 'engineering'",nativeQuery = true)
	List<Books> getAllBooksByEngineering();
	
	@Query(value="select * from books  where genre = 'ncert'",nativeQuery = true)
	List<Books> getAllBooksByNcert();
	
	@Query(value="select * from books  where author = :author",nativeQuery = true)
	List<Books> getAllBooksByAuthor(@Param("author") String author);
    
	@Query(value="select * from books  where book_name = :name",nativeQuery = true)
	List<Books> getAllBooksByName(@Param("name") String name);
    
	@Modifying
	@Transactional
	@Query(value = "insert into books(book_id,book_name,author,language,publication_date,genre,description,price,quantity,image) values(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10)",nativeQuery=true)
	int insert(@Param("id") int book_id,@Param("name") String book_name,@Param("author") String author,@Param("lang") String language,@Param("pubdate") String publication_date,@Param("gen") String genre,@Param("des") String description,@Param("cost") int price,@Param("qty") int quantity,@Param("img") String image );
	

}
