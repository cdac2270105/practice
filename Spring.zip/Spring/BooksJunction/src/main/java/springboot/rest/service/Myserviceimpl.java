package springboot.rest.service;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springboot.rest.dao.Mydaorepository;
import springboot.rest.dao.cartinterface;
import springboot.rest.dao.wishinterface;
import springboot.rest.model.Books;
import springboot.rest.model.Cart;
import springboot.rest.model.Wishlist;

@Service
public class Myserviceimpl implements Myservice {

	@Autowired
	Mydaorepository dao;
	
	@Autowired
	cartinterface cart;
	
	@Autowired
	wishinterface wish;
/*      
	public List<Employee> getEmployees() {
		return dao.findAll();
	}
	@Override
	public Optional<Employee> getEmployeeById(int empid) {
		return dao.findById(empid);
	}
	@Override
	public Employee addNewEmployee(Employee emp) {
		return dao.save(emp);
	}
	@Override
	public Employee updateEmployee(Employee emp) {
		return dao.save(emp);
	}
	@Override
	public void deleteEmployeeById(int empid) {
		dao.deleteById(empid);
	}
	@Override
	public void deleteAllEmployees() {
		dao.deleteAll();
	}*/
	
	 
		@Override
		public int insertBook(Books b) {
			return dao.insert(b.getBook_id(),b.getBook_name(),b.getAuthor(),b.getLanguage(),b.getPublication_date(),b.getGenre(),b.getDescription(),b.getPrice(),b.getQuantity(),b.getImage());
		}
     
	@Override
	public Cart addCart(Cart c) {
		return cart.save(c);
	}
	
	@Override
	public int deleteCart(Cart c) {
		return   cart.delete(c.getBook_id());
	}
	
	
	@Override
	public Wishlist addWish(Wishlist w) {
		return wish.save(w);
	}
	
	@Override
	public int deleteWish(Wishlist w) {
		return   wish.delete(w.getBook_id());
	}
	
	
	@Override
	public List<Books> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Books> getBookById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	public List<Books> getBookByCat(int value) 
	{
		System.out.println("getbookbycat called");
		List<Books> temp = null;// TODO Auto-generated method stub
		if(value==3)
		{
			 temp=dao.getAllBooksByRomance();
		}
		else if(value==1)
		{
			temp= dao.getAllBooksByComedy();
		}
		
		else if(value==2)
		{
			temp= dao.getAllBooksByBiography();
		}
		
		else if(value==4)
		{
			temp= dao.getAllBooksBySports();
		}
		
		else if(value==5)
		{
			temp= dao.getAllBooksByFicion();
		}
		
		else if(value==6)
		{
			temp= dao.getAllBooksByMedical();
		}
		
		else if(value==7)
		{
			temp= dao.getAllBooksByEngineering();
		}
		else if(value==8)
		{
			temp= dao.getAllBooksByNcert();
		}
		
		else if(value==9)
		{
			temp= getAll();
		}
		
		return temp;
	}

	@Override
	public List<Books> getBookByName(String value) {
		
		List<Books> li=dao.getAllBooksByName(value);
		List<Books> li2=dao.getAllBooksByAuthor(value);
		List<Books> li3=new ArrayList(li);
		li3.addAll(li2);
		return li3;
	}


	

	@Override
	public List<Cart> findbyname(String n) {
		// TODO Auto-generated method stub
		return cart.findbyname(n);
	}
	@Override
	public List<Wishlist> findbyname1(String n) {
		// TODO Auto-generated method stub
		return wish.findbyname(n);
	}
	
}