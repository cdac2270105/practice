import { Component, OnInit } from '@angular/core';
import { Customers } from '../Customers';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customeraccount',
  templateUrl: './customeraccount.component.html',
  styleUrls: ['./customeraccount.component.css']
})
export class CustomeraccountComponent implements OnInit {

  constructor(public r:Router) { 

    this.user=sessionStorage.getItem("name");
 
    this.fetchdetail();
  }

  ngOnInit() {
  }
  user:string;
name:string;
email:string;
mobile:number;
address:string;


//fetching  user detail from localstorage
fetchdetail()
{
for(var i =0;i<localStorage.length;i++)
  {
     let obj=new Customers();
    var key=localStorage.key(i);
     obj=JSON.parse(localStorage.getItem(key));
    if(obj.name==this.user)
    {
      console.log(JSON.stringify(obj));
      this.name=(obj.name);
      this.mobile=obj.mobile;
      this.email=(obj.email);
      this.address=(obj.address);
       
    }
  }
}

edit()
{
  this.r.navigate(['edit']);
}


}
