import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { CustomerregistrationComponent } from './customerregistration/customerregistration.component';
import { BooksellComponent } from './booksell/booksell.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';
import { CustomerwishlistComponent } from './customerwishlist/customerwishlist.component';
import { AboutComponent } from './about/about.component';
import { HomesearchComponent } from './homesearch/homesearch.component';
import { CustomercartComponent } from './customercart/customercart.component';
import { CustomeraccountComponent } from './customeraccount/customeraccount.component';
import { CustomereditComponent } from './customeredit/customeredit.component';
import { CustomersearchComponent } from './customersearch/customersearch.component';
import { CustomersearchbarComponent } from './customersearchbar/customersearchbar.component';

const routes: Routes = [
  {path:'',pathMatch:'full',component:HomepageComponent},
  {path:'login',component:CustomerloginComponent},
  {path:'register',component:CustomerregistrationComponent},
  {path:'sell',component:BooksellComponent},
  {path:'cprofile',component:CustomerprofileComponent},
  {path:'wishlist',component:CustomerwishlistComponent},
  {path:'contact',component:ContactusComponent},
  {path:'about',component:AboutComponent},
  {path:'homesearch/:value',component:HomesearchComponent},
  {path:'cart',component:CustomercartComponent},
  {path:'wish',component:CustomerwishlistComponent},
  {path:'account',component:CustomeraccountComponent},
  {path:'edit',component:CustomereditComponent},
  {path:'csbar/:data',component:CustomersearchbarComponent},
  {path:'csearch/:n',component:CustomersearchComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
