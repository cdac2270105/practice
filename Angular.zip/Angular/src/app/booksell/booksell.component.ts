import { Component, OnInit } from '@angular/core';
import { Books } from '../Books';
import {DbserviceService} from '../dbservice.service';

@Component({
  selector: 'app-booksell',
  templateUrl: './booksell.component.html',
  styleUrls: ['./booksell.component.css']
})
export class BooksellComponent implements OnInit {
  constructor(private s:DbserviceService)
  {}
  
  book_id:string;
  book_name:string;
  author:string;
  price:number;
  language:string;
  publication_date:string;
  image:string;
  genre:string;
  description:string;
  quantity:number;
  


ngOnInit() 
{
  
}

//Sell(bkid:any,bkname:any,au:any,lang:any,pub:any,gen:any,desc:any,price:any,qty:any,img:any)
//{
Sell()
{
  // let sellobj = new Books(this.book_id,this.book_name,this.author, this.price,this.language,
  // this.publication_date,this.image,this.genre,this.description,this.quantity);

  // localStorage.setItem(this.book_name,JSON.stringify(sellobj));
  // var s = JSON.parse(localStorage.getItem(this.book_name))
  // console.log(sellobj);
  

  //    alert("inserted");
  alert("Called");
              
              let obj = new Books(this.book_id,this.book_name,this.author, this.price,this.language,
                 this.publication_date,this.image,this.genre,this.description,this.quantity);
             // let obj=new Books(bkid,bkname,au,lang,pub,gen,desc,price,qty,img);
            
           this.s.insertbooks(obj).subscribe((data)=>{
             console.log(data);
             alert( "inserted in books");
             window.location.reload();
            // this.result=JSON.stringify(data);
           });



   
}

Reset()
{
  this.book_id = "";
  this.book_name = "";
  this.author = "";
  this.price = null;
  this.language = "";
  this.publication_date = "";
  this.image = null;
  this.genre = "";
  this.description = "";
  this.quantity = null;
}

}
