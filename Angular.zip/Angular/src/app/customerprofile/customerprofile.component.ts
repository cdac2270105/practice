import { Component, OnInit } from '@angular/core';
import { Books } from '../Books';
import { Router } from '@angular/router';
import { Customers } from '../Customers';

@Component({
  selector: 'app-customerprofile',
  templateUrl: './customerprofile.component.html',
  styleUrls: ['./customerprofile.component.css']
})
export class CustomerprofileComponent implements OnInit {

  constructor(public r:Router) { 
    this.user=sessionStorage.getItem("name");
    this.datafetch(); 
    
  }

  ngOnInit() {
  }
user:string;
name:string;
mb:any;
email:any;
add:any;
  
datafetch()
{
  for(var i =0;i<localStorage.length;i++)
  {
     let obj=new Customers();
    var key=localStorage.key(i);
     obj=JSON.parse(localStorage.getItem(key));
    if(obj.name==this.user)
    {
     // console.log(JSON.stringify(obj));
      this.name=(obj.name);
      this.mb=obj.mobile;
      this.email=(obj.email);
      this.add=(obj.address);
  }
  }
}

}
