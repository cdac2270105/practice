import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Books } from './Books';
import { HttpClient } from '@angular/common/http';
import { Cart } from './Cart';
import { Wish } from './Wish';


@Injectable({
  providedIn: 'root'
})
export class DbserviceService {
  
  

  constructor(private con:HttpClient) { }

url='http://localhost:8081';


  servicecallbyid(value:any):Observable<Books>
  {
    
    let link ="/book_id/"+value;
    return this.con.get<Books>(this.url+link);
  }


  servicecallbynameandauthor(value:any):Observable<Books>
  {
    
    let link ="/bookbyname/"+value;
    return this.con.get<Books>(this.url+link);
  }
  
  servicecallforall(n:any) 
  {
    let link ="/bookcat/"+n;
    return this.con.get<Books>(this.url+link);

  }

   addtocart(obj:Cart):Observable<Cart>
   {
    let link ="/addingcart";
    return this.con.put<Cart>((this.url+link),obj);
   }  

   addtowish(obj:Wish):Observable<Wish>
   {
    let link ="/addingwish";
    return this.con.put<Wish>((this.url+link),obj);
   }  

   fetchcart()
   {
     var n=sessionStorage.getItem("name");  
    let link ="/fetchcart?x="+n;
    return this.con.get<Cart>(this.url+link);
   }

   fetchwish()
   {
     var n=sessionStorage.getItem("name");  

    let link ="/fetchwish?x="+n;
    return this.con.get<Wish>(this.url+link);
   }

   delete(obj:Wish):Observable<Wish>
   {
    let link ="/deletewish";
    return this.con.put<Wish>((this.url+link),obj);
   }  

   delete1(obj:Cart):Observable<Cart>
   {
    let link ="/delete";
    return this.con.put<Cart>((this.url+link),obj);
   }  

insertbooks(obj:Books):Observable<Books>
   {
    let link ="/insert";
    return this.con.put<Books>((this.url+link),obj);
   }  


}
