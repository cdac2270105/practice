import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerwishlistComponent } from './customerwishlist.component';

describe('CustomerwishlistComponent', () => {
  let component: CustomerwishlistComponent;
  let fixture: ComponentFixture<CustomerwishlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerwishlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerwishlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
