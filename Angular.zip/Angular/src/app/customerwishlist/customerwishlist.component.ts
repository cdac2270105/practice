import { Component, OnInit } from '@angular/core';
import { DbserviceService } from '../dbservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Cart } from '../Cart';
import { stringify } from '@angular/compiler/src/util';
import { Books } from '../Books';
import { Wish } from '../Wish';

@Component({
  selector: 'app-customerwishlist',
  templateUrl: './customerwishlist.component.html',
  styleUrls: ['./customerwishlist.component.css']
})
export class CustomerwishlistComponent implements OnInit {

  
  constructor(public r:Router,private route:ActivatedRoute,private s:DbserviceService) { 
    this.name=sessionStorage.getItem("name");

    this.s.fetchwish().subscribe((data)=>
    {
      console.log(data);
     var len=JSON.parse(JSON.stringify(data)).length;
             for(var i=0;i<len;i++)
             {
               let obj=new Wish(this.name, this.book_id);
               obj.user=data[i].name;
               obj.book_id=data[i].book_id;
               this.result.push(obj);
               console.log(obj);
             } 
             this.addwish();
    });
    

  }


  ngOnInit() {
 }
result:any[]=[];
result2:any[]=[];
name:string;
book_id:number;



 book_name:string;
 author:string;
 price:number;
 language:string;
 publication_date:string;
 image:string;
 genre:string;
 description:string;
 quantity:number;

 remove(bkid:any)
 {
   alert("Called");
               alert(bkid);
               let obj=new Wish(this.name,bkid);
             
            this.s.delete(obj).subscribe((data)=>{
              console.log(data);
              alert( "removed from wishlist");
              window.location.reload();
             // this.result=JSON.stringify(data);
            });
          }

cart(bkid:any)
          {
              let obj=new Cart(this.name,bkid);
           this.s.addtocart(obj).subscribe((data)=>{
             console.log(data);
             alert("added to cart");
             this.remove(bkid);

            // this.result=JSON.stringify(data);
           });
           /*.subscribe((data)=>
           {
             alert("added");
           }
           );*/
          }
addwish()
{
  for(var i=0;i<this.result.length;i++)
  {
    this.s.servicecallbyid(this.result[i].book_id).subscribe((data)=>
    {
      let obj =new Books(data.book_id,data.book_name,data.author,data.price,data.language,data.publication_date,data.image,data.genre,data.description,data.quantity);
    this.result2.push(obj);
    })
  }
}}
