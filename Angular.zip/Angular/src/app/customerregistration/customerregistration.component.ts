import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Customers } from '../Customers';


@Component({
  selector: 'app-customerregistration',
  templateUrl: './customerregistration.component.html',
  styleUrls: ['./customerregistration.component.css']
})
export class CustomerregistrationComponent implements OnInit {

  name:string;
  mobile:number;
  email:string;
  address:string;
  password:string;
  constructor(public r:Router) { }

  ngOnInit() {
  }
  

  register()
  {
    this.r.navigate(['login']);
    let object =new Customers();
    object.Name=this.name;
    object.Mobile=this.mobile;
    object.Address=this.address;
    object.Email=this.email;
    object.Pass=this.password;
    localStorage.setItem(this.name,JSON.stringify(object));
    //console.log(object);
    //console.log(JSON.stringify(object));
    var obj=JSON.parse(localStorage.getItem(this.name));
    
    console.log(obj);
   console.log(obj.name);
   
    alert("Registered Successfully");
  }

}
