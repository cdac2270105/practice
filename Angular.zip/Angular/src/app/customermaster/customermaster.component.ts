import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { DbserviceService } from '../dbservice.service';

@Component({
  selector: 'app-customermaster',
  templateUrl: './customermaster.component.html',
  styleUrls: ['./customermaster.component.css']
})
export class CustomermasterComponent implements OnInit {

  constructor(public r:Router) { }

  ngOnInit() {
    this.r.routeReuseStrategy.shouldReuseRoute = function(){
      return false;
  };
  
  this.r.events.subscribe((evt) => {
      if (evt instanceof NavigationEnd) {
          this.r.navigated = false;
          window.scrollTo(0, 0);
      }
  });
  }
name:any;
  homenav(n:any)
  {
   if(n==1)
   {
    // alert("worrks");
    this.r.navigate(['csearch',n]);
   }
   else if(n==2)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==3)
   {
    this.r.navigate(['csearch',n]);
   } 
   else if(n==4)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==5)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==6)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==7)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==8)
   {
    this.r.navigate(['csearch',n]);
   }
   else if(n==9)
   {
    this.r.navigate(['csearch',n]);
   }
  }

  searchbar()
  {
    this.r.navigate(['csbar',this.name]);
  }
}
