import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customers } from '../Customers';
import { stringify } from 'querystring';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {

  constructor(public r:Router) 
  { 
    console.log(localStorage.length);
  for(var i=0;i<localStorage.length;i++)
  {
    var key=localStorage.key(i);
   console.log(localStorage.getItem(key));
  }
  }

  ngOnInit() {
  }
  
  login:string;
  password:string;
  count:number;
  uname:string;
check()
{
  let obj=new Customers();
  for(var i=0;i<localStorage.length;i++)
  {
    
    var key=localStorage.key(i);
    obj =JSON.parse(localStorage.getItem(key)); 
    if(obj.name==this.login && obj.password==this.password)
      {
      this.count=1;
      this.uname=obj.name;
      }
  }
  if(this.count==1)
  {
    sessionStorage.setItem("name",this.uname);
    this.r.navigate(['cprofile']);
  }
  else
  {
    alert("userid/password incorrect");
  }
  
  
}
}
