import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerorderhistory',
  templateUrl: './customerorderhistory.component.html',
  styleUrls: ['./customerorderhistory.component.css']
})
export class CustomerorderhistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
