import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Books } from '../Books';
import { DbserviceService } from '../dbservice.service';
import { Cart } from '../Cart';
import {Wish} from '../Wish';

@Component({
  selector: 'app-customersearch',
  templateUrl: './customersearch.component.html',
  styleUrls: ['./customersearch.component.css']
})
export class CustomersearchComponent implements OnInit {

  
  constructor(public r:Router,private route:ActivatedRoute,private s:DbserviceService) { 
    this.name=sessionStorage.getItem("name");  
  }

  ngOnInit() {
    console.log("Reached custs");
    let value=parseInt(this.route.snapshot.paramMap.get('n'));
 
  this.homenav(value);
  
  }

  name:string;
  books:any[]=[];
  result:any[]=[];

  book_id:string;
  book_name:string;
  author:string;
  price:number;
  language:string;
  publication_date:string;
  image:string;
  genre:string;
  description:string;
  quantity:number;
  


  homenav(value:number)
  {
    
    if(value==1)
    {
      this.comedycollection(value);
    }
    else if(value==2)
    {
      this.biographycollection(value);
    }
    else if(value==3)
    {
      this.romancecollection(value);
    }
    else if(value==4)
    {
      this.sportscollection(value);
      //console.log(value);
    }

    else if(value==5)
    {
      this.fictioncollection(value);
      //console.log(value);
    }

    else if(value==6)
    {
      this.medicalcollection(value);
      //console.log(value);
    }

    else if(value==7)
    {
      this.engineeringcollection(value);
      //console.log(value);
    }

    else if(value==8)
    {
      this.ncertcollection(value);
      //console.log(value);
    }

    else if(value==9)
    {
      this.all(value);
      //console.log(value);
    }
  }



  ncertcollection(v:any) 
    {
      this.result=[];
      console.log("ncert Called");
      this.servicecommon(v);
    }
  engineeringcollection(v:any) 
    {
      this.result=[];
      console.log("engineering Called");
      this.servicecommon(v);
    }
  
  medicalcollection(v:any) 
    {
      this.result=[];
      console.log("medical Called");
      this.servicecommon(v);
    }
  fictioncollection(v:any) 
    {
      this.result=[];
      console.log("fiction Called");
      this.servicecommon(v);
    }
  comedycollection(v:any)
    {
      this.result=[];
      console.log("Comedy Called");
      this.servicecommon(v);
    }

    home()
    {
      this.result=[];
    }

    biographycollection(v:any)
    {
      this.result=[];
      console.log("Biography Called");
      this.servicecommon(v);
    } 

    sportscollection(v:any)
    {
      this.result=[];
      console.log("Sports Called");
      this.servicecommon(v);
    }
    romancecollection(v:any)
    {
      this.result=[];
      console.log("Romance Called");
      this.servicecommon(v);
      
    }
all(v:any)
{
  this.result=[];
  console.log("all Called");
  this.servicecommon(v);
}

     servicecommon(v:any)
          {
            this.s.servicecallforall(v).subscribe((data)=>
            {
              var len=JSON.parse(JSON.stringify(data)).length;
              for(var i=0;i<len;i++)
              {
                let obj=new Books(data[i].book_id,data[i].book_name,data[i].author,data[i].price,data[i].language,data[i].publication_date,data[i].image,data[i].genre,data[i].description,data[i].quantity);
                this.result.push(obj);
              }
            }
            );
          }


          addcart(bkid:any)
          {
              let obj=new Cart(this.name,bkid);
           this.s.addtocart(obj).subscribe((data)=>{
             console.log(data);
             alert("added to cart");
            // this.result=JSON.stringify(data);
           });
           /*.subscribe((data)=>
           {
             alert("added");
           }
           );*/
          }


          addwish(bkid:any)
          {
              alert("Called");
              alert(bkid);
              let obj=new Wish(this.name,bkid);
           this.s.addtowish(obj).subscribe((data)=>{
             console.log(data);
             alert("added to wishlist");
            // this.result=JSON.stringify(data);
           });
           /*.subscribe((data)=>
           {
             alert("added");
           }
           );*/
          }
}