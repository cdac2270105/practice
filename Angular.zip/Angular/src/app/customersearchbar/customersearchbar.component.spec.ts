import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomersearchbarComponent } from './customersearchbar.component';

describe('CustomersearchbarComponent', () => {
  let component: CustomersearchbarComponent;
  let fixture: ComponentFixture<CustomersearchbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomersearchbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomersearchbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
