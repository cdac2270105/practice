import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DbserviceService } from '../dbservice.service';
import { Books } from '../Books';

@Component({
  selector: 'app-customersearchbar',
  templateUrl: './customersearchbar.component.html',
  styleUrls: ['./customersearchbar.component.css']
})
export class CustomersearchbarComponent implements OnInit {

  constructor(private r:ActivatedRoute,private s:DbserviceService) { }

  ngOnInit() {
    let value=(this.r.snapshot.paramMap.get('data'));
    this.assign(value);
  }
value:string;


book_id:string;
book_name:string;
author:string;
price:number;
language:string;
publication_date:string;
image:string;
genre:string;
description:string;
quantity:number;

result:any[]=[];

assign(v:string)
{
//console.log(v);
/*let obj=new Books(this.book_id,this.book_name,this.author, this.price,this.language,
  this.publication_date,
  this.image,
  this.genre,
  this.description,
  this.quantity);*/
this.s.servicecallbynameandauthor(v).subscribe((data)=> 
            {
              console.log(JSON.stringify(data));
              var len=JSON.parse(JSON.stringify(data)).length;
              for(var i=0;i<len;i++)
              {
                let obj=new Books(data[i].book_id,data[i].book_name,data[i].author,data[i].price,data[i].language,data[i].publication_date,data[i].image,data[i].genre,data[i].description,data[i].quantity);
                this.result.push(obj);
              }
            }
     );

}
}
