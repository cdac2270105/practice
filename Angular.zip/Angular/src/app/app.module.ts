import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { CustomerwishlistComponent } from './customerwishlist/customerwishlist.component';
import { CustomercartComponent } from './customercart/customercart.component';
import { CustomerorderhistoryComponent } from './customerorderhistory/customerorderhistory.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';
import { CustomerregistrationComponent } from './customerregistration/customerregistration.component';
import { BooksellComponent } from './booksell/booksell.component';
import { AboutComponent } from './about/about.component';
import { HomesearchComponent } from './homesearch/homesearch.component';
import { ForgotpassComponent } from './forgotpass/forgotpass.component';
import { CustomereditComponent } from './customeredit/customeredit.component';
import { CustomeraccountComponent } from './customeraccount/customeraccount.component';
import { CustomermasterComponent } from './customermaster/customermaster.component';
import { HomesearchbarComponent } from './homesearchbar/homesearchbar.component';
import { CustomersearchbarComponent } from './customersearchbar/customersearchbar.component';
import { CustomersearchComponent } from './customersearch/customersearch.component';
import { PaymentComponent } from './payment/payment.component';


@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    ContactusComponent,
    CustomerloginComponent,
    CustomerwishlistComponent,
    CustomercartComponent,
    CustomerorderhistoryComponent,
    CustomerprofileComponent,
    CustomerregistrationComponent,
    BooksellComponent,
    AboutComponent,
    HomesearchComponent,
    ForgotpassComponent,
    CustomereditComponent,
    CustomeraccountComponent,
    CustomermasterComponent,
    HomesearchbarComponent,
    CustomersearchbarComponent,
    CustomersearchComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
