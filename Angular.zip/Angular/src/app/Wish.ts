export class Wish 
{

	
	public user:string;
    public book_id:number;

    constructor(user:string, book_id:number)
    {
      this.book_id=book_id;
      this.user=user;
    }

    get BookId()
    {
        return this.book_id;
    }
    set BookId(book_id:number)
    {
        this.book_id=book_id;
    }


    get User()
    {
        return this.user;
    }
    set User(user:string)
    {
        this.user=user;
    }
}