import { Component, OnInit } from '@angular/core';
import { DbserviceService } from '../dbservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Cart } from '../Cart';
import { stringify } from '@angular/compiler/src/util';
import { Books } from '../Books';

@Component({
  selector: 'app-customercart',
  templateUrl: './customercart.component.html',
  styleUrls: ['./customercart.component.css']
})
export class CustomercartComponent implements OnInit {
  constructor(private s:DbserviceService)
  {
  


     this.s.fetchcart().subscribe((data)=>
     {
       console.log(data);
      var len=JSON.parse(JSON.stringify(data)).length;
              for(var i=0;i<len;i++)
              {
                let obj=new Cart(this.name, this.book_id);
                obj.user=data[i].user;
                obj.book_id=data[i].book_id;
                this.result.push(obj);
                console.log(obj);
              } 
              this.cart();
     });
     

   }


   ngOnInit() {
  }
result:any[]=[];
result2:any[]=[];
name:string;
book_id:number;



  book_name:string;
  author:string;
  price:number;
  language:string;
  publication_date:string;
  image:string;
  genre:string;
  description:string;
  quantity:number;


cart()
{
  for(var i=0;i<this.result.length;i++)
  {
    this.s.servicecallbyid(this.result[i].book_id).subscribe((data)=>
    {
      let obj =new Books(data.book_id,data.book_name,data.author,data.price,data.language,data.publication_date,data.image,data.genre,data.description,data.quantity);
    this.result2.push(obj);
     });
  }
}
remove(bkid:any)
{
  alert("Called");
              alert(bkid);
              let obj=new Cart(this.name,bkid);
            
           this.s.delete1(obj).subscribe((data)=>{
             console.log(data);
             alert( "removed from cart");
             window.location.reload();
            // this.result=JSON.stringify(data);
           });
           /*.subscribe((data)=>
           {
             alert("added");
           }
           );*/
          
         
}

}