import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { Books } from '../Books';



@Component({
  selector: 'app-homesearch',
  template: `
  
<div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar-fixed-top">
<a class="navbar-brand" href="#">MyBookStore</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
  <ul class="navbar-nav mr-auto" >
    <li class="nav-item active">
        <a class="nav-link" routerLink="" routerLinkActive="active">Home <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" routerLink="/about" routerLinkActive="active">About Us</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" routerLink="/contact" routerLinkActive="active">Contact Us</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Search Books By Categories
      </a>
      <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <button class="dropdown-item" (click)='homenav(1)' >Comedy</button>
        <a class="dropdown-item" (click)='homenav(2)'>Biography</a>
        <a class="dropdown-item" (click)='homenav(3)'>Romance</a>
        <a class="dropdown-item" (click)='homenav(4)'>Sports</a>
        <a class="dropdown-item" (click)='homenav(5)'>All</a>
      </div>
    </li>
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <li> <a class="nav-link" routerLink="/login" routerLinkActive="active">Login</a></li>
  </ul>
  <form class="form-inline my-2 my -lg-0 ">
    <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
    <button class="btn btn-secondary my-2 my-sm-0" type="submit" >Search</button>
  </form> 
</div>
</nav>

</div>

  <div  style="height:400px;margin-bottom:10px">
  <ul>
    <li *ngFor="let a of result;" style="padding:20px">
    <table border="1" width="500px" height="300px">
    <tr>
    <td><img height="170px" width="130px" src="./assets/{{a.image}}"></td>
    </tr>
    <tr>
    <td>BookId- </td><td>{{ a.book_id }}</td>
    </tr>
    <tr>
    <td>BookName- </td><td>{{ a.book_name }}</td>
    </tr>
    <tr>
    <td>BookAuthor- </td><td>{{ a.author }}</td>
    </tr>
    <tr>
    <td>BookPrice- </td><td>{{ a.price }}</td>
    </tr>
    <tr>
    <td>BookLanguage- </td><td>{{ a.language }}</td>
    </tr>
    <tr>
    <td>Description- </td><td>{{ a.description }}</td>
    </tr>
    <tr>
    <td><button style="width:150px;background:red;"><a style="color:white" (click)='invalid()' href="">Add to WishList</a></button></td><td><button style="width:150px;background:blue;"><a style="color:white" href="" (click)='invalid()'>Add to Cart</a></button></td>
    </tr>
    </table></li>
  </ul>
  </div>`,
  styleUrls: ['./homesearch.component.css']
})
export class HomesearchComponent implements OnInit {

  constructor(private r:Router,private route:ActivatedRoute) 
   {
     
   }

  ngOnInit() {
    let value=parseInt(this.route.snapshot.paramMap.get('value'));
 // this.navvalue=value;
  this.homenav(value);
  }
  //navvalue:number;
  books:any[]=[];
comedy:any[]=[];
romance:any[]=[];
sports:any[]=[];
result:any[]=[];

invalid()
{
  alert("Login First to Add");
  this.r.navigate(['login']);
}

homenav(value:number)
  {
    if(value==1)
    {
      this.comedycollection();
    }
    else if(value==2)
    {
      this.biographycollection();
    }
    else if(value==3)
    {
      this.romancecollection();
    }
    else if(value==4)
    {
      this.sportscollection();
      console.log(value);
    }
    else
    {
      this.all();
      console.log(value);
    }
    console.log(value);
   // this.navigatecheck();
    //this.r.navigate(['homesearch']);
  }
  comedycollection()
    {
      this.result=[];
      console.log("Comedy Called");
      
    }

    biographycollection()
    {
      this.result=[];
      console.log("biography Called");
    } 

    sportscollection()
    {
      this.result=[];
      console.log("Sports Called");
    }
    romancecollection()
    {
      this.result=[];
      console.log("Romance Called");
      for(var i=0;i<this.books.length;i++)
        {
          let obj=this.books[i];
            if(obj.genre=='Romance')
              {
                console.log(JSON.stringify(obj));
                this.result.push(obj);
              }

        }
    }
all()
{
  this.result=[];
  for(var i=0;i<this.books.length;i++)
    {
      console.log("Working");
      console.log(this.books.length);
      let obj=this.books[i];
      this.result.push(obj);

    }
}

comedycollection2()
{
  for(var i=0;i<this.books.length;i++)
    {
      console.log("Working");
      console.log(this.books.length);
      let obj=this.books[i];
     if(obj.genre=='Romance')
     {
       console.log(JSON.stringify(obj));
     }

    }
}

}
