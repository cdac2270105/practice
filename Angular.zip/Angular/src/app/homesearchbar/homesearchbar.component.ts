import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homesearchbar',
  templateUrl: './homesearchbar.component.html',
  styleUrls: ['./homesearchbar.component.css']
})
export class HomesearchbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
