import { Component, OnInit } from '@angular/core';
import { Customers } from '../Customers';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customeredit',
  templateUrl: './customeredit.component.html',
  styleUrls: ['./customeredit.component.css']
})
export class CustomereditComponent implements OnInit {
  constructor(public r:Router) { 
    this.user=sessionStorage.getItem("name");
 
    this.fetchdetail();
  }

  ngOnInit() {
  }

user:string;
name:string;
email:string;
mobile:number;
address:string;
password:any;

//new value
nname:string;
nemail:string;
nmobile:number;
naddress:string;
npassword:any;




//fetching  user detail from localstorage
fetchdetail()
{
for(var i =0;i<localStorage.length;i++)
  {
     let obj=new Customers();
    var key=localStorage.key(i);
     obj=JSON.parse(localStorage.getItem(key));
    if(obj.name==this.user)
    {
     // console.log(JSON.stringify(obj));
      this.name=(obj.name);
      this.mobile=obj.mobile;
      this.email=(obj.email);
      this.address=(obj.address);
      this.password=(obj.password);
      localStorage.removeItem(key);
     
  }
  }
}


 editdetail()
  {
  
  
        let obj=new Customers();
        obj.Name=this.name;
        if(this.nmobile==null)
        {
          obj.Mobile=this.mobile;
        }
        else
        {
          obj.Mobile=this.nmobile;
        }

        if(this.naddress==null)
        {
          obj.Address=this.address;
        }
        else
        {
          obj.Address=this.naddress;
        }

        if(this.nemail==null)
        {
          obj.Email=this.email;
        }
        else
        {
          obj.Email=this.nemail;
        }
        
        if(this.npassword==null)
        {
          obj.Pass=this.password;
        }
        else
        {
          obj.Pass=this.npassword;
        }
        
        
        //setting value
        console.log(obj);
        localStorage.setItem(this.name,JSON.stringify(obj));
        
        
       
       
       
       
      // console.log(obj);
      //console.log(this.name);
       alert("changes done Successfully");
       
        
      
        
      }
    }
    
  

   

















